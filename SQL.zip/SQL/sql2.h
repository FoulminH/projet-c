#include <stdio.h>
#include <stdlib.h>
#include <sqlite3.h>
#include <string.h>


void add_joueurs();

char* recup_played(char* pseudo);

char* recup_win(char* pseudo);

char* recup_lose(char* pseudo);
